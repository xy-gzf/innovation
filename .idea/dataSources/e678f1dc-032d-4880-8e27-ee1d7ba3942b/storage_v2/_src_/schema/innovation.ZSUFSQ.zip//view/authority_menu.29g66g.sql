create view authority_menu as
select `innovation`.`sys_base_menus`.`id`                              AS `id`,
       `innovation`.`sys_base_menus`.`created_at`                      AS `created_at`,
       `innovation`.`sys_base_menus`.`updated_at`                      AS `updated_at`,
       `innovation`.`sys_base_menus`.`deleted_at`                      AS `deleted_at`,
       `innovation`.`sys_base_menus`.`menu_level`                      AS `menu_level`,
       `innovation`.`sys_base_menus`.`parent_id`                       AS `parent_id`,
       `innovation`.`sys_base_menus`.`path`                            AS `path`,
       `innovation`.`sys_base_menus`.`name`                            AS `name`,
       `innovation`.`sys_base_menus`.`hidden`                          AS `hidden`,
       `innovation`.`sys_base_menus`.`component`                       AS `component`,
       `innovation`.`sys_base_menus`.`title`                           AS `title`,
       `innovation`.`sys_base_menus`.`icon`                            AS `icon`,
       `innovation`.`sys_base_menus`.`sort`                            AS `sort`,
       `innovation`.`sys_authority_menus`.`sys_authority_authority_id` AS `authority_id`,
       `innovation`.`sys_authority_menus`.`sys_base_menu_id`           AS `menu_id`,
       `innovation`.`sys_base_menus`.`keep_alive`                      AS `keep_alive`,
       `innovation`.`sys_base_menus`.`default_menu`                    AS `default_menu`
from (`innovation`.`sys_authority_menus`
         join `innovation`.`sys_base_menus`
              on ((`innovation`.`sys_authority_menus`.`sys_base_menu_id` = `innovation`.`sys_base_menus`.`id`)));

